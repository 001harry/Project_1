package LockedMe;

public class MenuOps 
{
	public static void printWelcomeScreen(String appName, String developerName) 
	{
		String companyDetails = String.format(
				  "\n"
				+ "Hello, welcome to %s. \n" 
			    + "Developed by %s\n", appName, developerName);
		
		String appFunction = 
				  "Functions :\n"
				+ "File Retrieval from \"main\" folder.\n"
				+ "Search, Add, or Delete files from \"main\" folder.\n";
		
		System.out.println(companyDetails);
		System.out.println(appFunction);
	}

	public static void displayMenu() 
	{
		String menu = 
				  "\nPlease select an option from the list below and press Enter:\n"
				+ "1. Retrieve all files from \"main\" folder.\n" 
				+ "2. Display File Options Menu.\n"
				+ "3. Exit program.\n";
		System.out.println(menu);
	}

	public static void displayFileMenuOptions() 
	{
		String fileMenu = 
				  "\nPlease select an option from the list below and press Enter:\n"
				+ "1. Add file to \"main\" folder\n" 
				+ "2. Delete file from \"main\" folder\n"
				+ "3. Search file from \"main\" folder\n" 
				+ "4. Show Previous Menu\n" 
				+ "5. Exit program\n";
		System.out.println(fileMenu+ "\n");
	}
}