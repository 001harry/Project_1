package LockedMe;

import java.util.List;
import java.util.Scanner;

public class HandleOps 
{
	public static void handleWelcomeScreenInput() 
	{
		boolean running = true;
		Scanner sc = new Scanner(System.in);
		do 
		{
			try 
			{
				MenuOps.displayMenu();
				int input = sc.nextInt();

				switch (input) 
				{
				case 1:
					FileOps.displayAllFiles("main");
					break;
				case 2:
					HandleOps.handleFileMenuOptions();
					break;
				case 3:
					System.out.println("Program exited successfully.");
					running = false;
					sc.close();
					System.exit(0);
					break;
				default:
					System.out.println("Please select a valid option from above.");
				}
			} 
			catch (Exception e) 
			{
				System.out.println(e.getClass().getName());
				handleWelcomeScreenInput();
			} 
		} 
		while (running == true);
	}
	
	public static void handleFileMenuOptions() 
	{
		boolean running = true;
		Scanner sc = new Scanner(System.in);
		do 
		{
			try 
			{
				MenuOps.displayFileMenuOptions();
				FileOps.createMainFolder("main");
				
				int input = sc.nextInt();
				switch (input) 
				{
				case 1:
					
					System.out.println("Please enter the name of the file to be added to the \"main\" folder");
					String fileToAdd = sc.next();
					
					FileOps.createFile(fileToAdd, sc);
					
					break;
				case 2:
					
					System.out.println("Please enter the name of the file to be deleted from \"main\" folder");
					String fileToDelete = sc.next();
					
					FileOps.createMainFolder("main");
					List<String> filesToDelete = FileOps.displayFileLocations(fileToDelete, "main");
					
					String deletionPrompt = 
							"\nSelect index of file to be deleted..."
							+ "\n(Enter 0 to delete all elements)";
					System.out.println(deletionPrompt);
				
					int idx = sc.nextInt();
					
					if (idx != 0) 
					{
						FileOps.deleteFileRecursively(filesToDelete.get(idx - 1));
					} 
					else 
					{
						for (String path : filesToDelete) {
							FileOps.deleteFileRecursively(path);
						}
					}

					break;
				case 3:

					System.out.println("Please enter the name of the file to be searched from \"main\" folder");
					String fileName = sc.next();
					
					FileOps.createMainFolder("main");
					FileOps.displayFileLocations(fileName, "main");

					break;
				case 4:

					return;
					
				case 5:
					System.out.println("Program exited successfully.");
					running = false;
					sc.close();
					System.exit(0);
				default:
					System.out.println("Please select a valid option from above.");
				}
			} 
			catch (Exception e) 
			{
				System.out.println(e.getClass().getName());
				handleFileMenuOptions();
			}
		} while (running == true);
	}
}