package LockedMe;

public class LockedMeMain 
{
	public static void main(String[] args) 
	{
		FileOps.createMainFolder("main");
		
		MenuOps.printWelcomeScreen("LockedMe File Management System", "Company Lockers Pvt. Ltd.");
		
		HandleOps.handleWelcomeScreenInput();
	}
}